# LAB 4

Implementing a simple proxy server

To Run the proxy server, type the following

```sh
chmod +x proxyServer.py
```

```sh
./proxyServer.py [hostName] [portNumber]
```

where `hostName` and `portNumber` are optional fields\
The default value for `hostName` and `portNumber` are `localhost` and `8998` respectively

## Contributors

[Neeraj Krishna N](https://github.com/nnk03) - 112101033
[Evans Samuel Biju](https://github.com/Samuel7Evans7Ph) - 112101017
