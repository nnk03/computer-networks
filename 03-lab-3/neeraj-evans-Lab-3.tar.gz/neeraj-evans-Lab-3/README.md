# Lab - 3 Solutions

## Submitted by

### Neeraj Krishna N - 112101033

### Evans Samuel Biju - 112101017

[Server and Client of A](./A) done by Neeraj
[Server and Client of B](./B) done by Evans
